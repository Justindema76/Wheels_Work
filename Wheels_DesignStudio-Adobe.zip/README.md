# Wheels_DesignStudio — install guide

This connects your Design Studio's "Email Design Files" button to your Magento store's
existing email system. It does **not** touch any core Magento files — it's a brand new,
self-contained folder.

## What's in this ZIP

```
app/code/Wheels/DesignStudio/     <- the module itself
README.md                         <- this file
```

## 1. Copy the module onto the server

Copy the `app` folder from this ZIP into your Magento root, so you end up with:

```
<magento-root>/app/code/Wheels/DesignStudio/...
```

(If `app/code/Wheels/` doesn't exist yet, just create it — this does not conflict with
any other "Wheels..." module already on the store.)

## 2. Turn it on (run these from the Magento root, as the deploy user)

```bash
php bin/magento module:enable Wheels_DesignStudio
php bin/magento setup:upgrade
php bin/magento setup:di:compile
php bin/magento cache:flush
```

If the store runs in production mode and uses static content deployment, also run:

```bash
php bin/magento setup:static-content:deploy -f
```

## 3. Configure it in the Admin

Go to **Stores → Configuration → Wheels → Design Studio** and set:

- **Enable Design Submissions** → Yes
- **Production Recipient Email** → the inbox that should receive designs
- **CC Email** → optional
- **Magento Sender Identity** → pick one of your existing Store Email Addresses
  (Stores → Configuration → General → Store Email Addresses)
- **Maximum Upload Size (MB)** → default 25, matches the frontend's current limit

Click **Save Config**.

## 4. Point the frontend at the new endpoint

In the site's HTML (wherever the Design Studio pages are served from), change:

```html
<meta name="wheels-design-email-endpoint" content="">
```

to:

```html
<meta name="wheels-design-email-endpoint" content="https://wheelsauto.com/rest/V1/wheels-design/submit">
```

That's the only frontend change needed — the JavaScript that builds the ZIP and submits
the form already exists and already reads this exact meta tag.

## 5. Test it

From the Design Studio page, build a design and click "Email Design Files." You should
see a success alert, and the configured recipient should receive an email with the ZIP
attached.

You can also test directly with curl:

```bash
curl -X POST "https://wheelsauto.com/rest/V1/wheels-design/submit" \
  -F "design_files=@/path/to/test.zip" \
  -F "product=Test Product" \
  -F "print_method=Screen Print" \
  -F "design_summary=Test submission" \
  -F "file_name=test-design"
```

Expected success response:

```json
{"success":true,"message":"Design files sent successfully."}
```

If something's wrong (submissions disabled, bad file, etc.) you'll get a non-200 response
with a plain-language `message` field explaining why.

## Notes

- No email password or credentials live in this module — it reuses the SMTP relay
  already configured under Advanced → System → Mail Sending Settings.
- Only `.zip` files are accepted, and they're checked against the configured max size and
  a real MIME-type check (not just the file extension).
- If this store's server disables `bin/magento setup:di:compile` in production mode (some
  hosts require it to run during deployment rather than manually), work this step into
  your normal deploy pipeline instead of running it by hand.
