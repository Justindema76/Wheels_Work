<?php
declare(strict_types=1);

namespace Wheels\DesignStudio\Model;

use Magento\Framework\Filesystem\Driver\File as FileDriver;
use Magento\Framework\Mail\AddressFactory;
use Magento\Framework\Mail\EmailMessageInterfaceFactory;
use Magento\Framework\Mail\MimeMessageInterfaceFactory;
use Magento\Framework\Mail\MimePartInterfaceFactory;
use Magento\Framework\Mail\TransportInterfaceFactory;
use Magento\Framework\Module\Dir;
use Magento\Framework\Module\Dir\Reader as ModuleDirReader;
use Magento\Framework\Webapi\Exception as WebapiException;
use Psr\Log\LoggerInterface;
use Wheels\DesignStudio\Api\Data\DesignSubmissionResultInterface;
use Wheels\DesignStudio\Api\Data\DesignSubmissionResultInterfaceFactory;
use Wheels\DesignStudio\Api\DesignSubmissionManagementInterface;

/**
 * Handles incoming Design Studio production package submissions.
 *
 * IMPORTANT: Magento's REST/webapi framework only auto-decodes a JSON request body into
 * service method arguments. This endpoint receives multipart/form-data (a ZIP file plus a
 * few text fields), which Magento does not auto-bind that way. Because of that, submit()
 * takes no formal parameters, and the multipart fields/files are read directly from PHP's
 * $_POST / $_FILES superglobals - these are populated normally by PHP for any multipart
 * POST request no matter what framework layer sits on top, so this is reliable across
 * Magento versions. This is the standard, widely used pattern for file uploads through a
 * Magento 2 REST endpoint.
 *
 * Sending itself goes through Magento's own core mail classes (Mime + Address + Transport),
 * the same plumbing Magento uses for every other system email - so it automatically honors
 * whatever is configured under Stores > Configuration > Advanced > System > Mail Sending
 * Settings (currently: SMTP via smtp.office365.com). Nothing here talks to SMTP directly and
 * no credentials are handled by this module.
 */
class DesignSubmissionManagement implements DesignSubmissionManagementInterface
{
    private const ALLOWED_EXTENSION = 'zip';

    private const ALLOWED_MIME_TYPES = [
        'application/zip',
        'application/x-zip-compressed',
        'application/octet-stream',
    ];

    /**
     * @var Config
     */
    private $config;

    /**
     * @var AddressFactory
     */
    private $addressFactory;

    /**
     * @var MimePartInterfaceFactory
     */
    private $mimePartFactory;

    /**
     * @var MimeMessageInterfaceFactory
     */
    private $mimeMessageFactory;

    /**
     * @var EmailMessageInterfaceFactory
     */
    private $emailMessageFactory;

    /**
     * @var TransportInterfaceFactory
     */
    private $transportFactory;

    /**
     * @var DesignSubmissionResultInterfaceFactory
     */
    private $resultFactory;

    /**
     * @var ModuleDirReader
     */
    private $moduleDirReader;

    /**
     * @var FileDriver
     */
    private $fileDriver;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @param Config $config
     * @param AddressFactory $addressFactory
     * @param MimePartInterfaceFactory $mimePartFactory
     * @param MimeMessageInterfaceFactory $mimeMessageFactory
     * @param EmailMessageInterfaceFactory $emailMessageFactory
     * @param TransportInterfaceFactory $transportFactory
     * @param DesignSubmissionResultInterfaceFactory $resultFactory
     * @param ModuleDirReader $moduleDirReader
     * @param FileDriver $fileDriver
     * @param LoggerInterface $logger
     */
    public function __construct(
        Config $config,
        AddressFactory $addressFactory,
        MimePartInterfaceFactory $mimePartFactory,
        MimeMessageInterfaceFactory $mimeMessageFactory,
        EmailMessageInterfaceFactory $emailMessageFactory,
        TransportInterfaceFactory $transportFactory,
        DesignSubmissionResultInterfaceFactory $resultFactory,
        ModuleDirReader $moduleDirReader,
        FileDriver $fileDriver,
        LoggerInterface $logger
    ) {
        $this->config = $config;
        $this->addressFactory = $addressFactory;
        $this->mimePartFactory = $mimePartFactory;
        $this->mimeMessageFactory = $mimeMessageFactory;
        $this->emailMessageFactory = $emailMessageFactory;
        $this->transportFactory = $transportFactory;
        $this->resultFactory = $resultFactory;
        $this->moduleDirReader = $moduleDirReader;
        $this->fileDriver = $fileDriver;
        $this->logger = $logger;
    }

    /**
     * @inheritDoc
     */
    public function submit(): DesignSubmissionResultInterface
    {
        if (!$this->config->isEnabled()) {
            throw new WebapiException(
                __('Design Studio submissions are currently disabled.'),
                0,
                WebapiException::HTTP_SERVICE_UNAVAILABLE
            );
        }

        $recipient = $this->config->getRecipientEmail();
        if (!$recipient) {
            $this->logger->error('Wheels_DesignStudio: no production recipient email is configured.');
            throw new WebapiException(
                __('Design Studio is not fully configured yet. Please try again later.'),
                0,
                WebapiException::HTTP_SERVICE_UNAVAILABLE
            );
        }

        [$product, $printMethod, $designSummary, $fileName] = $this->readFormFields();
        [$fileContent, $attachmentName] = $this->readAndValidateFile();

        $subject = sprintf('New Design Studio Submission: %s (%s)', $product, $printMethod);
        $htmlBody = $this->buildEmailBody($product, $printMethod, $designSummary, $fileName);

        try {
            $htmlPart = $this->mimePartFactory->create([
                'content' => $htmlBody,
                'type' => 'text/html',
                'charset' => 'utf-8',
            ]);

            $attachmentPart = $this->mimePartFactory->create([
                'content' => $fileContent,
                'type' => 'application/zip',
                'disposition' => 'attachment',
                'encoding' => 'base64',
                'filename' => $attachmentName,
            ]);

            $mimeMessage = $this->mimeMessageFactory->create([
                'parts' => [$htmlPart, $attachmentPart],
            ]);

            $toAddresses = [$this->addressFactory->create(['email' => $recipient])];

            $ccEmail = $this->config->getCcEmail();
            $ccAddresses = $ccEmail ? [$this->addressFactory->create(['email' => $ccEmail])] : [];

            $emailMessage = $this->emailMessageFactory->create([
                'body' => $mimeMessage,
                'to' => $toAddresses,
                'from' => [$this->resolveSenderAddress()],
                'cc' => $ccAddresses,
                'subject' => $subject,
            ]);

            $transport = $this->transportFactory->create(['message' => $emailMessage]);
            $transport->sendMessage();
        } catch (\Throwable $e) {
            $this->logger->error(
                'Wheels_DesignStudio: failed to send design submission email: ' . $e->getMessage(),
                ['exception' => $e]
            );
            throw new WebapiException(
                __('The design files could not be emailed right now. Please try again shortly.'),
                0,
                WebapiException::HTTP_INTERNAL_ERROR
            );
        }

        /** @var DesignSubmissionResultInterface $result */
        $result = $this->resultFactory->create();
        $result->setSuccess(true);
        $result->setMessage((string)__('Design files sent successfully.'));

        return $result;
    }

    /**
     * Read and sanitize the plain text submission fields.
     *
     * @return string[]
     * @throws WebapiException
     */
    private function readFormFields(): array
    {
        $product = trim((string)($_POST['product'] ?? ''));
        $printMethod = trim((string)($_POST['print_method'] ?? ''));
        $designSummary = trim((string)($_POST['design_summary'] ?? ''));
        $fileName = trim((string)($_POST['file_name'] ?? ''));

        if ($product === '' || $printMethod === '' || $fileName === '') {
            throw new WebapiException(
                __('Missing required submission details.'),
                0,
                WebapiException::HTTP_BAD_REQUEST
            );
        }

        return [
            $this->sanitizeText($product),
            $this->sanitizeText($printMethod),
            $this->sanitizeText($designSummary),
            $this->sanitizeText($fileName),
        ];
    }

    /**
     * Read, validate, and return the uploaded ZIP contents plus a safe attachment file name.
     *
     * @return array{0: string, 1: string}
     * @throws WebapiException
     */
    private function readAndValidateFile(): array
    {
        if (empty($_FILES['design_files']) || !is_array($_FILES['design_files'])) {
            throw new WebapiException(
                __('No design file was received.'),
                0,
                WebapiException::HTTP_BAD_REQUEST
            );
        }

        $file = $_FILES['design_files'];
        $tmpName = (string)($file['tmp_name'] ?? '');
        $originalName = (string)($file['name'] ?? 'design.zip');
        $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        $size = (int)($file['size'] ?? 0);

        if ($error !== UPLOAD_ERR_OK) {
            throw new WebapiException(
                __('The uploaded design file could not be processed.'),
                0,
                WebapiException::HTTP_BAD_REQUEST
            );
        }

        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            throw new WebapiException(
                __('Invalid file upload.'),
                0,
                WebapiException::HTTP_BAD_REQUEST
            );
        }

        $extension = strtolower((string)pathinfo($originalName, PATHINFO_EXTENSION));
        if ($extension !== self::ALLOWED_EXTENSION) {
            throw new WebapiException(
                __('Only ZIP files are accepted.'),
                0,
                WebapiException::HTTP_BAD_REQUEST
            );
        }

        $maxBytes = $this->config->getMaxUploadSizeBytes();
        if ($size <= 0 || $size > $maxBytes) {
            throw new WebapiException(
                __('The design file exceeds the maximum allowed size of %1 MB.', round($maxBytes / 1024 / 1024, 1)),
                0,
                WebapiException::HTTP_BAD_REQUEST
            );
        }

        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = $finfo ? finfo_file($finfo, $tmpName) : null;
            if ($finfo) {
                finfo_close($finfo);
            }

            if ($mimeType && !in_array($mimeType, self::ALLOWED_MIME_TYPES, true)) {
                throw new WebapiException(
                    __('The uploaded file does not appear to be a valid ZIP archive.'),
                    0,
                    WebapiException::HTTP_BAD_REQUEST
                );
            }
        }

        $content = file_get_contents($tmpName);
        if ($content === false) {
            throw new WebapiException(
                __('The uploaded design file could not be read.'),
                0,
                WebapiException::HTTP_INTERNAL_ERROR
            );
        }

        $safeName = $this->sanitizeFileName(pathinfo($originalName, PATHINFO_FILENAME)) . '.zip';

        return [$content, $safeName];
    }

    /**
     * Resolve the "from" address using the configured Magento sender identity
     * (Stores > Configuration > General > Store Email Addresses).
     *
     * @return \Magento\Framework\Mail\AddressInterface
     */
    private function resolveSenderAddress()
    {
        return $this->addressFactory->create([
            'email' => $this->config->getSenderEmail(),
            'name' => $this->config->getSenderName(),
        ]);
    }

    /**
     * Build the notification email HTML body from the module's template file.
     *
     * @param string $product
     * @param string $printMethod
     * @param string $designSummary
     * @param string $fileName
     * @return string
     */
    private function buildEmailBody(
        string $product,
        string $printMethod,
        string $designSummary,
        string $fileName
    ): string {
        $template = $this->loadTemplate();

        $replacements = [
            '{{product}}' => $product,
            '{{print_method}}' => $printMethod,
            '{{design_summary}}' => nl2br($designSummary),
            '{{file_name}}' => $fileName,
            '{{submitted_at}}' => date('Y-m-d H:i:s'),
        ];

        return strtr($template, $replacements);
    }

    /**
     * @return string
     */
    private function loadTemplate(): string
    {
        try {
            $templatePath = rtrim(
                $this->moduleDirReader->getModuleDir(Dir::MODULE_VIEW_DIR, 'Wheels_DesignStudio'),
                '/'
            ) . '/frontend/email/design_submission.html';

            if ($this->fileDriver->isExists($templatePath)) {
                return $this->fileDriver->fileGetContents($templatePath);
            }
        } catch (\Throwable $e) {
            $this->logger->warning(
                'Wheels_DesignStudio: could not load email template, using fallback. ' . $e->getMessage()
            );
        }

        return '<html><body style="font-family:Arial,sans-serif;">'
            . '<h2>New Design Studio Submission</h2>'
            . '<p><strong>Product:</strong> {{product}}</p>'
            . '<p><strong>Print Method:</strong> {{print_method}}</p>'
            . '<p><strong>File Name:</strong> {{file_name}}</p>'
            . '<p><strong>Submitted:</strong> {{submitted_at}}</p>'
            . '<p><strong>Design Summary:</strong><br>{{design_summary}}</p>'
            . '</body></html>';
    }

    /**
     * @param string $value
     * @return string
     */
    private function sanitizeText(string $value): string
    {
        return htmlspecialchars(strip_tags($value), ENT_QUOTES, 'UTF-8');
    }

    /**
     * @param string $value
     * @return string
     */
    private function sanitizeFileName(string $value): string
    {
        $value = preg_replace('/[^A-Za-z0-9_\-]+/', '-', $value) ?? 'design';
        $value = trim($value, '-');

        return $value !== '' ? $value : 'design';
    }
}
