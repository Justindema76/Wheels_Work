<?php
declare(strict_types=1);

namespace Wheels\DesignStudio\Model\Data;

use Magento\Framework\DataObject;
use Wheels\DesignStudio\Api\Data\DesignSubmissionResultInterface;

class DesignSubmissionResult extends DataObject implements DesignSubmissionResultInterface
{
    /**
     * @inheritDoc
     */
    public function getSuccess(): bool
    {
        return (bool)$this->getData('success');
    }

    /**
     * @inheritDoc
     */
    public function setSuccess(bool $success)
    {
        return $this->setData('success', $success);
    }

    /**
     * @inheritDoc
     */
    public function getMessage(): string
    {
        return (string)$this->getData('message');
    }

    /**
     * @inheritDoc
     */
    public function setMessage(string $message)
    {
        return $this->setData('message', $message);
    }
}
