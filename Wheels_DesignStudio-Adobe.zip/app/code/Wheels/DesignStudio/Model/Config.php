<?php
declare(strict_types=1);

namespace Wheels\DesignStudio\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

/**
 * Reads Stores > Configuration > Wheels > Design Studio settings, plus the store's existing
 * Store Email Addresses (trans_email/*) so the module can reuse an existing sender identity
 * instead of introducing a second one.
 */
class Config
{
    private const XML_PATH_ENABLED = 'wheels_designstudio/general/enabled';
    private const XML_PATH_RECIPIENT_EMAIL = 'wheels_designstudio/general/recipient_email';
    private const XML_PATH_CC_EMAIL = 'wheels_designstudio/general/cc_email';
    private const XML_PATH_SENDER_IDENTITY = 'wheels_designstudio/general/sender_identity';
    private const XML_PATH_MAX_UPLOAD_SIZE_MB = 'wheels_designstudio/general/max_upload_size_mb';

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * @param int|null $storeId
     * @return bool
     */
    public function isEnabled(?int $storeId = null): bool
    {
        return (bool)$this->scopeConfig->isSetFlag(
            self::XML_PATH_ENABLED,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param int|null $storeId
     * @return string|null
     */
    public function getRecipientEmail(?int $storeId = null): ?string
    {
        $value = $this->scopeConfig->getValue(
            self::XML_PATH_RECIPIENT_EMAIL,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );

        return $value ? trim((string)$value) : null;
    }

    /**
     * @param int|null $storeId
     * @return string|null
     */
    public function getCcEmail(?int $storeId = null): ?string
    {
        $value = $this->scopeConfig->getValue(
            self::XML_PATH_CC_EMAIL,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );

        return $value ? trim((string)$value) : null;
    }

    /**
     * @param int|null $storeId
     * @return string
     */
    public function getSenderIdentity(?int $storeId = null): string
    {
        $value = $this->scopeConfig->getValue(
            self::XML_PATH_SENDER_IDENTITY,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );

        return $value ? (string)$value : 'general';
    }

    /**
     * Resolve the "from" email address for the configured sender identity, e.g.
     * trans_email/ident_general/email.
     *
     * @param int|null $storeId
     * @return string
     */
    public function getSenderEmail(?int $storeId = null): string
    {
        $identity = $this->getSenderIdentity($storeId);
        $value = $this->scopeConfig->getValue(
            sprintf('trans_email/ident_%s/email', $identity),
            ScopeInterface::SCOPE_STORE,
            $storeId
        );

        return $value ? (string)$value : 'no-reply@wheelsauto.com';
    }

    /**
     * @param int|null $storeId
     * @return string
     */
    public function getSenderName(?int $storeId = null): string
    {
        $identity = $this->getSenderIdentity($storeId);
        $value = $this->scopeConfig->getValue(
            sprintf('trans_email/ident_%s/name', $identity),
            ScopeInterface::SCOPE_STORE,
            $storeId
        );

        return $value ? (string)$value : 'Wheels Auto';
    }

    /**
     * @param int|null $storeId
     * @return int
     */
    public function getMaxUploadSizeBytes(?int $storeId = null): int
    {
        $mb = (float)$this->scopeConfig->getValue(
            self::XML_PATH_MAX_UPLOAD_SIZE_MB,
            ScopeInterface::SCOPE_STORE,
            $storeId
        );

        if ($mb <= 0) {
            $mb = 25.0;
        }

        return (int)round($mb * 1024 * 1024);
    }
}
