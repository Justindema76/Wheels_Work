<?php
declare(strict_types=1);

namespace Wheels\DesignStudio\Api\Data;

/**
 * Response returned by the Design Studio submission endpoint, e.g.
 * {"success":true,"message":"Design files sent successfully."}
 */
interface DesignSubmissionResultInterface
{
    /**
     * @return bool
     */
    public function getSuccess(): bool;

    /**
     * @param bool $success
     * @return $this
     */
    public function setSuccess(bool $success);

    /**
     * @return string
     */
    public function getMessage(): string;

    /**
     * @param string $message
     * @return $this
     */
    public function setMessage(string $message);
}
