<?php
declare(strict_types=1);

namespace Wheels\DesignStudio\Api;

use Wheels\DesignStudio\Api\Data\DesignSubmissionResultInterface;

/**
 * Service contract for POST /rest/V1/wheels-design/submit
 */
interface DesignSubmissionManagementInterface
{
    /**
     * Receive a Design Studio production package (multipart/form-data: design_files, product,
     * print_method, design_summary, file_name) and email it to the configured production
     * recipient using Magento's existing mail configuration.
     *
     * Deliberately takes no formal parameters - see Model\DesignSubmissionManagement for why.
     *
     * @return \Wheels\DesignStudio\Api\Data\DesignSubmissionResultInterface
     * @throws \Magento\Framework\Webapi\Exception
     */
    public function submit(): DesignSubmissionResultInterface;
}
