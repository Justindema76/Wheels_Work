<?php
/**
 * Wheels_DesignStudio
 *
 * Registers this module with Magento. Does not modify any core files.
 */
declare(strict_types=1);

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Wheels_DesignStudio',
    __DIR__
);
